<p align="center">  
  <img src="https://libreapi.cl/logo.png" width="200" alt="Logo"/>  
</p>  

# LibreAPI
[![License](https://img.shields.io/github/license/CamiloHernandez/libreapi)](https://github.com/ccuetoh/libreapi/blob/master/LICENSE)  
[![Website Status](https://img.shields.io/uptimerobot/status/m786861139-81aee65cd49486d2d9e3c006)](https://stats.uptimerobot.com/p9QANizwxn)

⚠️</br>
**This repository is now archived and the API will shut-down soon. If you need an alternative check the [APIs Chile](https://apis-chile.readme.io/reference/welcome) project.**</br>
**Este repositorio ha sido archivado y la API será desconectada pronto. Si necesitas una alternativa revisa el proyecto [APIs Chile](https://apis-chile.readme.io/reference/welcome).**</br>
⚠️

**English:**
LibreAPI is an open-source project to provide a public access API for Chilean developers.

**Español:**
LibreAPI es un proyecto de código abierto con el objetivo de ofrecer una API de libre acceso a los desarolladores chilenos.
