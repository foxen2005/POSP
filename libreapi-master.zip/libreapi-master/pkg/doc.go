package libreapi

const (
	Version    = "0.2.0"
	Descriptor = "LibreAPI v" + Version
	Author     = "Camilo Cueto"
	Licence    = "MIT"
)
